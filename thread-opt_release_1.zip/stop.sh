killall -15 thread-opt
